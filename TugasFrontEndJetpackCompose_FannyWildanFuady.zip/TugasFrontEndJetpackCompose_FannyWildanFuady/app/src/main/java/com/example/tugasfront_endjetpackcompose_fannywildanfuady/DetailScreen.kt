package com.example.tugasfront_endjetpackcompose_fannywildanfuady

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable

@Composable
fun DetailScreen(itemId: String?) {
    Column {
        TopAppBar(title = { Text("Detail Aitem") })
        Text("Nama Aitem: Holy Crystal $itemId")
        Text("Deskripsi: Ini adalah item magic termahal.")
    }
}